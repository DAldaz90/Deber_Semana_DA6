﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Daldaz90
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnSumar_Clicked(object sender, EventArgs e)
        {

            double NoUno = Convert.ToDouble(dato_uno.Text);
            double NoDos = Convert.ToDouble(dato_dos.Text);
            double resultado = NoUno + NoDos;
            result.Text = resultado.ToString();
            DisplayAlert("Alerta:", resultado.ToString(), "cerrar");

        }

    }
}
